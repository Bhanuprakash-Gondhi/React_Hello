//steps to follow docker setup
https://docs.docker.com/engine/reference/commandline/start/

1. Add a Dockerfile to the project root

# pull official base image
FROM node:13.12.0-alpine

# set working directory
WORKDIR /app

# add `/app/node_modules/.bin` to $PATH
ENV PATH /app/node_modules/.bin:$PATH

# install app dependencies
COPY package.json ./
COPY package-lock.json ./
RUN npm install --silent
RUN npm install react-scripts@3.4.1 -g --silent

# add app
COPY . ./

# start app
CMD ["npm", "start"]

2. Add a .dockerignore

node_modules
npm-debug.log
build
.dockerignore
**/.git
**/.DS_Store
**/node_modules

3. Add a docker-compose.yml file to the project root

version: '3.7'

services:

  sample:
    container_name: sample
    build:
      context: .
      dockerfile: Dockerfile
    volumes:
      - '.:/app'
      - '/app/node_modules'
    ports:
      - 3000:3000
    environment:
      - CHOKIDAR_USEPOLLING=true

4. run the below code in powershell

docker-compose up -d --build

5. to stop the container use
 
docker-compose stop