import React from 'react'
import Button from '@material-ui/core/Button';
const DownLoadButton = () => {

    const downloadData = () => {

        fetch('http://localhost:8080/employees/download')
            .then(response => {
                response.blob().then(blob => {
                    let url = window.URL.createObjectURL(blob);
                    let a = document.createElement('a');
                    a.href = url;
                    a.download = 'data.json';
                    a.click();
                });
                //window.location.href = response.url;
            });
    }
    return (
        <>
            <Button onClick={downloadData} size='small' color='primary'>
                Download
            </Button>
        </>
    )
}

export default DownLoadButton