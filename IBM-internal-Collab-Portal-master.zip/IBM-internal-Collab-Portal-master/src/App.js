import './App.css';
import Home from './component/homePage/homePage.component';
import Header from './component/navigation/header'

function App() {
  return (
    <div >
      <Header />
      <Home/>
    </div>
  );
}

export default App;
