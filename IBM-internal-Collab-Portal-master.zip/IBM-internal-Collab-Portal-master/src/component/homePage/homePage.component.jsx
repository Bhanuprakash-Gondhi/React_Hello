import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Grid from '@material-ui/core/Grid';
import CardItem from './cardItem/card-item.component';
import { Data } from '../../constant.data';
import FileUpload from './FileUpload'
const useStyles = makeStyles((theme) => ({
  root: {
    flexGrow: 1,
  },
  control: {
    padding: theme.spacing(2),
  },
}));

export default function Home() {
  const classes = useStyles();

  return (
    <div style={{ margin: 5 }}>
      <Grid container className={classes.root} spacing={2}>
        <Grid item xs={12}>
          <FileUpload />
        </Grid>
        <Grid item xs={12}>
          <Grid container justifyContent='center' spacing={'2'}>
            {Data.map((data) => (
              <Grid key={data.id} item>
                <CardItem data={data} />
              </Grid>
            ))}
          </Grid>
        </Grid>
      </Grid></div>
  );
}
