import React from 'react';
import { makeStyles } from '@material-ui/core/styles';
import Card from '@material-ui/core/Card';
import CardActionArea from '@material-ui/core/CardActionArea';
import CardActions from '@material-ui/core/CardActions';
import CardContent from '@material-ui/core/CardContent';
import CardMedia from '@material-ui/core/CardMedia';
import Button from '@material-ui/core/Button';
import Typography from '@material-ui/core/Typography';
import DownLoadButton from '../../../utils/Buttons/DownloadButton';
const useStyles = makeStyles({
  root: {
    width: 300,
    margin: 15,
  },
  media: {
    height: 140,
  },
});

const CardItem = (props) => {
  const classes = useStyles();
  console.log(props);
  return (
    <Card className={classes.root}>
      <CardActionArea>
        <CardMedia
          className={classes.media}
          image='/static/images/cards/contemplative-reptile.jpg'
          title='Contemplative Reptile'
        />
        <CardContent>
          <Typography gutterBottom variant='h5' component='h2'>
            {props.data.File_Name}
          </Typography>
          <Typography variant='body2' color='textSecondary' component='p'>
            <p>File size: {props.data.File_Size}</p>
            <p>Upload By: {props.data.Upload_By}</p>
            <p>Edited By: {props.data.Edited_By}</p>
            <p>Last Modified: {props.data.Last_Modified}</p>
          </Typography>
        </CardContent>
      </CardActionArea>
      <CardActions>
        <DownLoadButton />
      </CardActions>
    </Card>
  );
};
export default CardItem;
