export const Data = [
	{
		"id": 1,
		"File_Name": "ABH_123",
		"File_Size": 1+' KB',
		"Upload_By": "Alex Smith",
		"Edited_By": "Alex Smith",
		"Last_Modified": "11/28/20"
	},
	{
		"id": 2,
		"File_Name": "ABM_123",
		"File_Size": 2+' KB',
		"Upload_By": "Alex Smith",
		"Edited_By": "Alex Smith",
		"Last_Modified": "12/09/20"
	},
	{
		"id": 3,
		"File_Name": "ABP_123",
		"File_Size": 5+' KB',
		"Upload_By": "Alex Smith",
		"Edited_By": "Alex Smith",
		"Last_Modified": "08/30/20"
	},
	{
		"id": 4,
		"File_Name": "ABQ_123",
		"File_Size": 2 +' KB',
		"Upload_By": "Alex Smith",
		"Edited_By": "Alex Smith",
		"Last_Modified": "11/04/20"
	},
	{
		"id": 5,
		"File_Name": "ABV_123",
		"File_Size": 10 +' KB',
		"Upload_By": "Alex Smith",
		"Edited_By": "Alex Smith",
		"Last_Modified": "03/04/22"
	}
];
export const columns = [
	{ field: 'id', headerName: 'id', width: 150 },
	{
	  field: 'File_Name',
	  headerName: 'File name',
	  width: 200,
	  editable: true,
	},
	{
	  field: 'File_Size',
	  headerName: 'File Size',
	  width: 150,
	  editable: true,
	},
	{
	  field: 'Upload_By',
	  headerName: 'Uploaded By',
	  width: 200,
	  editable: true,
	},
	{
		field: 'Edited_By',
		headerName: 'Edited By',
		width: 200,
		editable: true,
	  },{
		field: 'Last_Modified',
		headerName: 'Last Modified',
		type: 'date',
		width: 150,
		editable: true,
	  },
  ];